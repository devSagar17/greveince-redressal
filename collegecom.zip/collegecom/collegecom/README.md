# College-Grievances-Redressal-System
Online Grievance with forward functionality using PHP, MYSQL, HTML and CSS.
### Functionality:
## Basic Working:
1. This website have 4 levels such as Committee Members , Principal , University ,and AITRC to forward grievance if any of this level members does not take any action within 7 days.
2. After 7 days student get option to forward grievance to next level if and only if not any action taken.
3. In University and AITRC level it only redirects user to their respective grievance portal.
4. All these status student can see at their dashboard

## Student Registration :
Student first fill registration for and if admin verifies account then only student can login.

## Adding Committee Members:
This all operation is done by Admin.

## Admin login credentials:
USERNAME : Admin
PASSWORD : 123456


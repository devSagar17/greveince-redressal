<?php
include_once '../helpers/init.php';

// principallogin
if (isset($_POST['login'])) {
    $username = filter_var($_POST['PrincipalName'], FILTER_SANITIZE_STRING);
    $password = $_POST['password'];

    try {
        $query = "SELECT * FROM principal WHERE name = :name";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':name', $username);
        $stmt->execute();
        $data = $stmt->fetch();

        if ($data && password_verify($password, $data['password'])) {
            $_SESSION['is_login'] = true;
            $_SESSION['USERNAME'] = $data['name'];
            $_SESSION['USER_ID'] = $data['id'];
            header('Location:../views/principaldashboard.php');
            exit;
        } else {
            $_SESSION["message"] = "Wrong username or password. Debug: Username: $username, Password: $password, Hashed Password: " . $data['password'];
            $_SESSION["msg_type"] = "danger";
            header('Location:../views/principallogin.php');
            exit;
        }
    } catch (PDOException $e) {
        $_SESSION["message"] = "Error: " . $e->getMessage();
        $_SESSION["msg_type"] = "danger";
        header('Location:../views/principallogin.php');
        exit;
    }
}

// logout
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location:../views/principallogin.php');
    exit;
}

// changePassword
if (isset($_POST['changePassword'])) {
    // Your change password code goes here
}

// Remove principal
if (isset($_POST['remove'])) {
    $delete_id = $_POST['id'];
    $stmt = $conn->prepare("DELETE FROM principal WHERE id = :id");
    $stmt->bindParam(':id', $delete_id);
    $stmt->execute();

    // Redirect the user
    header("Location:../views/principalaccount.php");
    exit;
}
?>

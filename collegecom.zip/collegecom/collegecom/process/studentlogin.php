<?php
session_start();
include_once '../helpers/init.php'; // Assuming this file contains the database connection

if (!isset($conn) || $conn === null) {
    echo "Database connection is not properly established.";
    exit;
}

// Student login
if (isset($_POST['login'])) {
    $email = filter_var($_POST['StudentEmail'], FILTER_SANITIZE_STRING);
    $password = $_POST['password']; // Do not sanitize password
    
    try {
        $query = "SELECT * FROM student WHERE email = :email";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($data && password_verify($password, $data['password']) && $data['status'] == 1) {
            // Successful login
            $_SESSION['is_login'] = true;
            $_SESSION['USERNAMES'] = $data['fullname'];
            $_SESSION['USER_ID'] = $data['id'];
            header('Location:../views/studentdashboard.php');
            exit;
        } else {
            // Failed login
            $_SESSION["message"] = "Wrong username or password.";
            $_SESSION["msg_type"] = "danger";
            header('Location:../views/studentlogin.php');
            exit;
        }
    } catch (PDOException $e) {
        // Log any database errors
        echo "Error: " . $e->getMessage(); 
        exit;
    }
}

// Logout
if (isset($_POST['logout'])) {
    session_destroy();
    header('Location:../views/studentlogin.php');
    exit;
}

// Change Password
if (isset($_POST['changePassword'])) {
    // Your change password code goes here
}
?>

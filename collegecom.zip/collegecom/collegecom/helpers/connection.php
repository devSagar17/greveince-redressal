<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "onlinegrievance";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // If the script reaches here, the connection is successful
    // Start session if needed
    session_start();
    echo "Connection successful"; // Only echo this message if the connection is successful
} catch (PDOException $e) {
    // If an exception is caught, the connection failed
    echo "Connection Failed: " . $e->getMessage();
    // You might want to handle the error gracefully or log it instead of displaying it directly to the user
    die(); // Stop script execution
}
// No need to close the connection here
?>

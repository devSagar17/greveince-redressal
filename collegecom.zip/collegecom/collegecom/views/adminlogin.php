<?php include_once '../helpers/init.php';
if (isset($_SESSION['ADMINNAME'])){
       header('Location:admindashboard.php');
     }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <style>
        body {
            background: #000;
        }
    </style>

    <title>Admin Login</title>
</head>

<body>
    <div class="container mx-auto">
        <nav class="bg-gray-800 p-6">
            <div class="container mx-auto flex justify-between items-center">
                <span class="text-white text-lg font-bold">Complaint register</span>
                <div class="flex">
                    <ul class="flex">
                        <li class="mr-6">
                            <a href="../index.php" class="text-white hover:text-gray-300">Home</a>
                        </li>
                        <li class="mr-6">
                            <a href="#" class="text-white hover:text-gray-300">Admin</a>
                        </li>
                        <li class="dropdown inline-block relative mr-6">
                            <a href="#" class="text-white hover:text-gray-300">
                                Login
                            </a>
                            <ul class="dropdown-menu absolute hidden text-gray-700 pt-1">
                                <li><a href="committeelogin.php"
                                        class="rounded-t bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">Committee
                                        Member</a></li>
                                <li><a href="principallogin.php"
                                        class="bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">Principal</a>
                                </li>
                                <li><a href="studentlogin.php"
                                        class="rounded-b bg-gray-200 hover:bg-gray-400 py-2 px-4 block whitespace-no-wrap">Student</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <?php
          if(isset($_SESSION["message"])) { ?>
        <div class="alert alert-<?=$_SESSION['msg_type']; ?> mx-auto mt-8 max-w-sm">
            <?php echo $_SESSION['message']; ?>
        </div>
        <?php  unset($_SESSION["message"]);
                }
           ?>
        <div class="flex justify-center items-center h-screen">
            <div class="w-full max-w-md">
                <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4" action="../process/adminlogin.php"
                    method="post" autocomplete="off">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="adminname">
                            Admin Name
                        </label>
                        <input
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                            id="adminname" type="text" name="adminname" placeholder="Enter a User Name" required
                            value="<?php echo isset($_SESSION['ADMINNAME']) ? $_SESSION['ADMINNAME'] : ''; ?>">
                    </div>
                    <div class="mb-6">
                        <label class="block text-gray-700 text-sm font-bold mb-2" for="adminpassword">
                            Password
                        </label>
                        <input
                            class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
                            id="adminpassword" type="password" name="adminpassword" placeholder="Enter a Password"
                            required>
                    </div>
                    <div class="flex items-center justify-between">
                        <button
                            class="bg-gray-800 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
                            type="submit" name="login">
                            Login
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
</body>

</html>

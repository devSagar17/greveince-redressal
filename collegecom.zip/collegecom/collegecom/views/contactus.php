<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Validate form data if needed

    // Process form data (For demonstration purposes, we'll just display it)
    echo "Name: $name <br>";
    echo "Email: $email <br>";
    echo "Message: $message <br>";

    // Additional processing logic can be added here, such as sending emails, saving to database, etc.

    exit(); // Stop further execution
}
?>

<section id="contact" style="background-color: #f5f5f5; padding: 50px 0;">
    <h1 class="section-header" style="text-align: center; margin-bottom: 30px; color: #333;">Contact</h1>
    <div class="contact-wrapper" style="display: flex; justify-content: center;">
        <form id="contact-form" class="form-horizontal" role="form" method="POST" style="width: 50%;">
            <div class="form-group">
                <input type="text" class="form-control" id="name" placeholder="Name" name="name" style="width: 100%; margin-bottom: 15px; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
            </div>
            <div class="form-group">
                <input type="email" class="form-control" id="email" placeholder="Email" name="email" style="width: 100%; margin-bottom: 15px; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required>
            </div>
            <div class="form-group">
                <textarea class="form-control" rows="5" placeholder="Message" name="message" style="width: 100%; margin-bottom: 15px; padding: 10px; border: 1px solid #ccc; border-radius: 5px;" required></textarea>
            </div>
            <button class="btn btn-primary send-button" id="submit" type="submit" value="SEND" style="width: 100%; background-color: #007bff; color: #fff; border: none; padding: 10px; border-radius: 5px; cursor: pointer;"><i class="fa fa-paper-plane"></i> Send</button>
        </form>

        <div class="direct-contact-container" style="margin-left: 30px; color: #333;">
            <ul class="contact-list" style="list-style-type: none; padding: 0;">
                <li class="list-item" style="margin-bottom: 15px;"><i class="fa fa-map-marker fa-2x" style="margin-right: 10px;"></i><span class="contact-text place">Chh.Sambhajinagar</span></li>
                <li class="list-item" style="margin-bottom: 15px;"><i class="fa fa-phone fa-2x" style="margin-right: 10px;"></i><span class="contact-text phone"><a href="tel:1-212-555-5555" title="Give me a call" style="color: #333; text-decoration: none;">8956479800</a></span></li>
                <li class="list-item" style="margin-bottom: 15px;"><i class="fa fa-envelope fa-2x" style="margin-right: 10px;"></i><span class="contact-text gmail"><a href="mailto:#" title="Send me an email" style="color: #333; text-decoration: none;">sagardhapate14@gmail.com</a></span></li>
            </ul>
            <hr style="border-color: #333;">
            <ul class="social-media-list" style="list-style-type: none; padding: 0;">
                <li style="display: inline-block; margin-right: 10px;"><a href="https://github.com/yourgithubusername" class="contact-icon"><i class="fa fa-github fa-2x" aria-hidden="true" style="color: #333;"></i></a></li>
                <li style="display: inline-block; margin-right: 10px;"><a href="https://codepen.io/yourcodepenusername" class="contact-icon"><i class="fa fa-codepen fa-2x" aria-hidden="true" style="color: #333;"></i></a></li>
                <li style="display: inline-block; margin-right: 10px;"><a href="https://twitter.com/yourtwitterhandle" class="contact-icon"><i class="fa fa-twitter fa-2x" aria-hidden="true" style="color: #333;"></i></a></li>
                <li style="display: inline-block; margin-right: 10px;"><a href="https://www.instagram.com/yourinstagramusername" class="contact-icon"><i class="fa fa-instagram fa-2x" aria-hidden="true" style="color: #333;"></i></a></li>
            </ul>
            <hr style="border-color: #333;">
            <div class="copyright" style="text-align: center;">&copy; ALL OF THE RIGHTS RESERVED</div>
        </div>
    </div>
</section>

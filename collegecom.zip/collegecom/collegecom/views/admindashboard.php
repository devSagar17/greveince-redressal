<?php
include_once '../helpers/init.php';
if (!isset($_SESSION['ADMINNAME'])){
       header('Location:adminlogin.php');
}
//Fetch Data
try {
    // FETCH DATA of principal
    $stmt = $conn->prepare("SELECT * FROM principal");
    $stmt->execute();
    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

    // FETCH DATA of committeemembers
    $stmt2 = $conn->prepare("SELECT * FROM committeemembers");
    $stmt2->execute();
    // set the resulting array to associative
    $result2 = $stmt2->setFetchMode(PDO::FETCH_ASSOC);

    // FETCH DATA of student
    $condition = 0;
    $stmt3 = $conn->prepare("SELECT * FROM student WHERE status='$condition'");
    $stmt3->execute();
    // set the resulting array to associative
    $result3 = $stmt3->setFetchMode(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Tailwind CSS -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">

    <title>Complaint register</title>
</head>

<body>
    <nav class="bg-gray-800 p-6">
        <div class="container mx-auto flex justify-between items-center">
            <span class="text-white text-lg font-bold">Complaint register</span>
            <span class="text-white text-lg font-bold">Admin Dashboard</span>
            <div class="flex">
                <ul class="flex">
                    <li class="mr-6">
                        <a href="../index.php" class="text-white hover:text-gray-300">Home</a>
                    </li>
                </ul>
                <form class="form-inline" action="../process/adminlogin.php" method="post">
                    <button class="btn btn-dark my-2 my-sm-0" type="submit" name="logout">LOGOUT</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container mx-auto">
        <?php require 'sub-views/admindashside.php'; ?>

        <div class="container mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
                <div class="bg-gray-800 text-white p-4 rounded">
                    <h5 class="font-bold">Principal</h5>
                    <?php foreach ($stmt->fetchAll() as $key => $value) : ?>
                        <p>Name: <?php echo $value['name']; ?></p>
                    <?php endforeach; ?>
                    <a href="principalaccount.php" class="btn btn-info mt-4">View</a>
                </div>
                <div class="bg-gray-800 text-white p-4 rounded">
                    <h5 class="font-bold">Committee Members</h5>
                    <?php foreach ($stmt2->fetchAll() as $key2 => $value2) : ?>
                        <p>Name: <?php echo $value2['name']; ?></p>
                        <p>Position: <?php echo $value2['position']; ?></p>
                        <hr>
                    <?php endforeach; ?>
                    <a href="Committeeaccount.php" class="btn btn-info mt-4">View</a>
                </div>
                <div class="bg-gray-800 text-white p-4 rounded">
                    <h5 class="font-bold">Student</h5>
                    <p>Number of students to be verified.</p>
                    <?php foreach ($stmt3->fetchAll() as $key3 => $value3) : ?>
                        <p>Name: <?php echo $value3['fullname']; ?></p>
                        <hr>
                    <?php endforeach; ?>
                    <a href="verifystudent.php" class="btn btn-info mt-4">View</a>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        /* Set the width of the side navigation to 250px and the left margin of the page content to 250px */
        function openNav() {
            document.getElementById("mySidenav").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
        }

        /* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
        function closeNav() {
            document.getElementById("mySidenav").style.width = "0";
            document.getElementById("main").style.marginLeft = "0";
        }
    </script>
</body>

</html>

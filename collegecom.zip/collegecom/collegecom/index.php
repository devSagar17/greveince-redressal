<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COLLEGE COMPLAINT REGISTRATION PORTAL</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #000;
            background-image: url('uploads/Complaints-Management.webp');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            height: 100vh; /* Ensure the body fills the viewport */
        }
        /* Additional Styles */
        .navbar {
            backdrop-filter: blur(5px); /* Apply blur effect to the navbar */
            background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background color */
        }
        .jumbotron {
            background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background for readability */
        }
        h1 {
            font-family: 'Poppins', sans-serif; /* Change font-family for headings */
        }
        p {
            font-size: 1.25rem; /* Increase font size for paragraphs */
        }
        .nav-link {
            transition: all 0.3s ease; /* Add transition effect for navigation links */
        }
        .nav-link:hover {
            transform: translateY(-3px); /* Add hover effect for navigation links */
        }
    </style>
</head>

<body class="text-center bg-gray-900 text-white">
    <nav class="navbar bg-gray-800 p-6">
        <div class="container mx-auto flex justify-between items-center">
            <span class="text-white text-xl font-bold">COLLEGE COMPLAINT REGISTRATION PORTAL</span>
            <div class="flex items-center">
                <a href="index.php" class="text-white mr-4 nav-link">Home</a>
                <a href="views/adminlogin.php" class="text-white mr-4 nav-link">Admin</a>
                <a href="views/contactus.php" class="text-white mr-4 nav-link">Contact Us</a>
                <!-- Login Dropdown -->
                <div class="relative">
                    <button class="text-white focus:outline-none nav-link">Login</button>
                    <div class="absolute right-0 mt-2 w-48 bg-white rounded-md overflow-hidden shadow-xl z-10 hidden">
                        <a href="views/committeelogin.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-200 nav-link">Committee Member</a>
                        <a href="views/principallogin.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-200 nav-link">Principal</a>
                        <a href="views/studentlogin.php" class="block px-4 py-2 text-gray-800 hover:bg-gray-200 nav-link">Student</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="container mx-auto">
        <div class="jumbotron bg-gray-900 text-white py-24">
            <div class="container mx-auto px-4">
                <h1 class="text-5xl mb-8 font-bold">COLLEGE COMPLAINT REGISTRATION PORTAL</h1>
                <p class="text-lg mb-8">Register your complaint to management through this portal. It has service to forward grievance to the next level if action is not taken by members level within time.</p>
                <a href="views/studentlogin.php" class="bg-gray-800 hover:bg-gray-700 text-white font-bold py-3 px-8 rounded-full inline-block transition duration-300">Get Started</a>
            </div>
        </div>
    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
    <script>
        // Toggle dropdown menu
        document.addEventListener("DOMContentLoaded", function () {
            const dropdownToggle = document.querySelector(".relative button");
            const dropdownMenu = document.querySelector(".relative .absolute");

            dropdownToggle.addEventListener("click", function () {
                dropdownMenu.classList.toggle("hidden");
            });

            // Close dropdown menu when clicking outside
            document.addEventListener("click", function (event) {
                if (!dropdownToggle.contains(event.target) && !dropdownMenu.contains(event.target)) {
                    dropdownMenu.classList.add("hidden");
                }
            });
        });
    </script>
</body>

</html>
